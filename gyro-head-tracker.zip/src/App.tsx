/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from "react";
import { useState, useEffect, useRef } from "react";
import { Settings, Play, Square, RotateCcw, Monitor, Smartphone, Info, AlertCircle } from "lucide-react";
import { motion } from "motion/react";

// --- Main App Component ---
export default function App() {
  const [isStreaming, setIsStreaming] = useState(false);
  const [status, setStatus] = useState<"idle" | "requesting" | "active" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  
  const [pcIp, setPcIp] = useState("192.168.1.110");
  const [pcPort, setPcPort] = useState("4242");
  const [sensitivity, setSensitivity] = useState(3.0);
  const [smoothing, setSmoothing] = useState(0.5); // 0 to 1, higher = smoother
  
  const [invertYaw, setInvertYaw] = useState(false);
  const [invertPitch, setInvertPitch] = useState(false);
  const [invertRoll, setInvertRoll] = useState(false);

  // UI display state (throttled)
  const [displayOrientation, setDisplayOrientation] = useState({ yaw: 0, pitch: 0, roll: 0 });
  
  // Internal tracking refs to avoid re-renders
  const orientationRef = useRef({ yaw: 0, pitch: 0, roll: 0 });
  const offsetRef = useRef({ yaw: 0, pitch: 0, roll: 0 });
  const smoothedRef = useRef({ yaw: 0, pitch: 0, roll: 0 });
  const lastUpdateRef = useRef(Date.now());
  const animationFrameRef = useRef<number | null>(null);

  const [isSupported, setIsSupported] = useState<boolean | null>(null);

  // Feature detection on mount
  useEffect(() => {
    setIsSupported(!!window.DeviceOrientationEvent);
  }, []);

  // Global error handler
  useEffect(() => {
    const handleError = (event: ErrorEvent) => {
      console.error("Global error caught:", event.error);
      setStatus("error");
      setErrorMessage(event.error?.message || "A runtime error occurred.");
    };
    window.addEventListener("error", handleError);
    return () => window.removeEventListener("error", handleError);
  }, []);

  // Reset Center
  const resetCenter = () => {
    console.log("Resetting center to current orientation:", orientationRef.current);
    offsetRef.current = { ...orientationRef.current };
  };

  const startTracking = async () => {
    console.log("Attempting to start tracking...");
    setStatus("requesting");
    setErrorMessage("");

    try {
      // Feature detection
      if (!window.DeviceOrientationEvent) {
        throw new Error("Device orientation sensors are not supported or available on this device.");
      }

      // iOS 13+ Permission Request
      const DOE = window.DeviceOrientationEvent as any;
      if (typeof DOE.requestPermission === "function") {
        const permission = await DOE.requestPermission();
        console.log("Permission result:", permission);
        if (permission !== "granted") {
          throw new Error("Sensor permission denied. Please enable motion access in settings.");
        }
      }

      setIsStreaming(true);
      setStatus("active");
      console.log("Tracking active.");
    } catch (err: any) {
      console.error("Start tracking error:", err);
      setStatus("error");
      setErrorMessage(err.message || "An error occurred while accessing sensors.");
    }
  };

  const stopTracking = () => {
    console.log("Stopping tracking.");
    setIsStreaming(false);
    setStatus("idle");
  };

  useEffect(() => {
    if (!isStreaming) return;

    const handleGyro = (event: DeviceOrientationEvent) => {
      try {
        if (!event) return;
        
        // Safe checks for sensor data
        if (event.alpha === null || event.beta === null || event.gamma === null) {
          // Some devices might fire the event but with null values initially
          return;
        }

        const rawYaw = event.alpha;
        const rawPitch = event.beta;
        const rawRoll = event.gamma;

        orientationRef.current = { yaw: rawYaw, pitch: rawPitch, roll: rawRoll };

        // Calculate relative movement
        let targetYaw = (rawYaw - offsetRef.current.yaw);
        let targetPitch = (rawPitch - offsetRef.current.pitch);
        let targetRoll = (rawRoll - offsetRef.current.roll);

        // Handle wrap-around for yaw (0-360)
        if (targetYaw > 180) targetYaw -= 360;
        if (targetYaw < -180) targetYaw += 360;

        // Apply sensitivity and inversion
        targetYaw *= sensitivity * (invertYaw ? -1 : 1);
        targetPitch *= sensitivity * (invertPitch ? -1 : 1);
        targetRoll *= sensitivity * (invertRoll ? -1 : 1);

        // Smoothing (LPF)
        const alpha = 1 - smoothing;
        smoothedRef.current.yaw = smoothedRef.current.yaw * smoothing + targetYaw * alpha;
        smoothedRef.current.pitch = smoothedRef.current.pitch * smoothing + targetPitch * alpha;
        smoothedRef.current.roll = smoothedRef.current.roll * smoothing + targetRoll * alpha;

        // Send to backend (throttled by gyro frequency)
        const now = Date.now();
        if (now - lastUpdateRef.current > 20) { // Max ~50Hz sending
          lastUpdateRef.current = now;
          
          fetch("/api/track", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              yaw: smoothedRef.current.yaw,
              pitch: smoothedRef.current.pitch,
              roll: smoothedRef.current.roll,
              ip: pcIp,
              port: parseInt(pcPort) || 4242,
            }),
          }).catch(err => {
            // Silently log network errors to avoid UI spam
            console.warn("UDP Proxy Error:", err.message);
          });
        }
      } catch (err) {
        console.error("Gyro processing error:", err);
      }
    };

    window.addEventListener("deviceorientation", handleGyro);

    // Throttled UI updates using requestAnimationFrame
    const updateUI = () => {
      setDisplayOrientation({ ...smoothedRef.current });
      animationFrameRef.current = requestAnimationFrame(updateUI);
    };
    animationFrameRef.current = requestAnimationFrame(updateUI);

    return () => {
      window.removeEventListener("deviceorientation", handleGyro);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isStreaming, pcIp, pcPort, sensitivity, smoothing, invertYaw, invertPitch, invertRoll]);

  if (status === "error" && !isStreaming) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center p-6 text-center">
        <div className="bg-neutral-900 border border-red-500/50 p-8 rounded-3xl max-w-md space-y-4">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
          <h1 className="text-xl font-bold text-white">Something went wrong</h1>
          <p className="text-neutral-400 text-sm">{errorMessage || "An unexpected error occurred."}</p>
          <button 
            onClick={() => window.location.reload()}
            className="px-6 py-2 bg-red-500 text-white rounded-xl font-bold hover:bg-red-600 transition-colors"
          >
            Reload App
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 font-sans selection:bg-blue-500/30">
      {/* Header */}
      <header className="p-6 border-b border-neutral-800 bg-neutral-900/50 backdrop-blur-md sticky top-0 z-10">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-600 rounded-xl shadow-lg shadow-blue-500/20">
              <Smartphone className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">Gyro Tracker</h1>
          </div>
          <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
            status === "active" ? "bg-green-500/10 text-green-400 border-green-500/20" : 
            status === "error" ? "bg-red-500/10 text-red-400 border-red-500/20" :
            status === "requesting" ? "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" :
            "bg-neutral-800 text-neutral-400 border-neutral-700"
          }`}>
            <div className={`w-2 h-2 rounded-full ${
              status === "active" ? "bg-green-500 animate-pulse" : 
              status === "error" ? "bg-red-500" :
              status === "requesting" ? "bg-yellow-500 animate-bounce" :
              "bg-neutral-600"
            }`} />
            {status === "active" ? "TRACKING ACTIVE" : 
             status === "error" ? "ERROR" :
             status === "requesting" ? "WAITING FOR PERMISSION" :
             "IDLE"}
          </div>
        </div>
      </header>

      <main className="p-6 max-w-md mx-auto space-y-8">
        {/* Support Warning */}
        {isSupported === false && (
          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-2xl p-4 flex gap-3 items-center">
            <Info className="w-5 h-5 text-yellow-500 shrink-0" />
            <p className="text-sm text-yellow-400">Device orientation sensors not found. Use a mobile device.</p>
          </div>
        )}

        {/* Error Display */}
        {status === "error" && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex gap-3 items-center"
          >
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <p className="text-sm text-red-400">{errorMessage}</p>
          </motion.div>
        )}

        {/* Status Display */}
        <section className="bg-neutral-900 rounded-3xl p-8 border border-neutral-800 shadow-xl overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Monitor className="w-24 h-24" />
          </div>
          
          <div className="grid grid-cols-3 gap-4 text-center relative z-10">
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Yaw</p>
              <p className="text-2xl font-mono font-medium text-blue-400">{displayOrientation.yaw.toFixed(1)}°</p>
            </div>
            <div className="space-y-1 border-x border-neutral-800">
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Pitch</p>
              <p className="text-2xl font-mono font-medium text-purple-400">{displayOrientation.pitch.toFixed(1)}°</p>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold text-neutral-500 uppercase tracking-widest">Roll</p>
              <p className="text-2xl font-mono font-medium text-emerald-400">{displayOrientation.roll.toFixed(1)}°</p>
            </div>
          </div>
        </section>

        {/* Controls */}
        <section className="space-y-6">
          <div className="flex gap-4">
            <button
              onClick={isStreaming ? stopTracking : startTracking}
              className={`flex-1 flex items-center justify-center gap-2 py-4 rounded-2xl font-bold transition-all active:scale-95 ${
                isStreaming ? "bg-red-500 hover:bg-red-600 shadow-lg shadow-red-500/20" : "bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20"
              }`}
            >
              {isStreaming ? <Square className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
              {isStreaming ? "Stop Tracking" : "Start Tracking"}
            </button>
            <button
              onClick={resetCenter}
              className="p-4 bg-neutral-800 hover:bg-neutral-700 rounded-2xl border border-neutral-700 transition-all active:scale-95"
              title="Reset Center"
            >
              <RotateCcw className="w-6 h-6" />
            </button>
          </div>

          {/* Settings Card */}
          <div className="bg-neutral-900 rounded-3xl p-6 border border-neutral-800 space-y-6">
            <div className="flex items-center gap-2 text-neutral-400 border-b border-neutral-800 pb-4">
              <Settings className="w-4 h-4" />
              <h2 className="text-sm font-bold uppercase tracking-wider">Configuration</h2>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-medium text-neutral-500 ml-1">PC IP Address</label>
                <input
                  type="text"
                  value={pcIp}
                  onChange={(e) => setPcIp(e.target.value)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                  placeholder="192.168.1.110"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-medium text-neutral-500 ml-1">UDP Port</label>
                <input
                  type="text"
                  value={pcPort}
                  onChange={(e) => setPcPort(e.target.value)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                  placeholder="4242"
                />
              </div>
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-neutral-400">Sensitivity: {sensitivity.toFixed(1)}x</label>
              </div>
              <input
                type="range"
                min="0.5"
                max="10.0"
                step="0.1"
                value={sensitivity}
                onChange={(e) => setSensitivity(parseFloat(e.target.value))}
                className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
              />
            </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-neutral-400">Smoothing: {(smoothing * 100).toFixed(0)}%</label>
              </div>
              <input
                type="range"
                min="0"
                max="0.95"
                step="0.05"
                value={smoothing}
                onChange={(e) => setSmoothing(parseFloat(e.target.value))}
                className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2">
              <button
                onClick={() => setInvertYaw(!invertYaw)}
                className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${invertYaw ? "bg-blue-500/20 border-blue-500/50 text-blue-400" : "bg-neutral-800 border-neutral-700 text-neutral-500"}`}
              >
                INV YAW
              </button>
              <button
                onClick={() => setInvertPitch(!invertPitch)}
                className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${invertPitch ? "bg-blue-500/20 border-blue-500/50 text-blue-400" : "bg-neutral-800 border-neutral-700 text-neutral-500"}`}
              >
                INV PITCH
              </button>
              <button
                onClick={() => setInvertRoll(!invertRoll)}
                className={`py-2 px-1 rounded-lg text-[10px] font-bold border transition-all ${invertRoll ? "bg-blue-500/20 border-blue-500/50 text-blue-400" : "bg-neutral-800 border-neutral-700 text-neutral-500"}`}
              >
                INV ROLL
              </button>
            </div>
          </div>
        </section>

        {/* Info Box */}
        <div className="bg-blue-500/5 border border-blue-500/20 rounded-2xl p-4 flex gap-3">
          <Info className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
          <div className="text-xs text-neutral-400 leading-relaxed">
            <p className="font-bold text-blue-300 mb-1">How to use:</p>
            <ol className="list-decimal ml-4 space-y-1">
              <li>Open <strong>OpenTrack</strong> on your PC.</li>
              <li>Set Input to <strong>UDP over network</strong>.</li>
              <li>Ensure your phone and PC are on the same network.</li>
              <li>Enter your PC's IP and click Start.</li>
            </ol>
          </div>
        </div>
      </main>

      <footer className="p-8 text-center text-neutral-600 text-[10px] font-medium tracking-widest uppercase">
        Built for OpenTrack • Low Latency Gyro
      </footer>
    </div>
  );
}


