import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import dgram from "dgram";

async function startServer() {
  const app = express();
  const PORT = 3000;
  const udpClient = dgram.createSocket("udp4");

  app.use(express.json());

  // API endpoint to forward head tracking data to UDP
  app.post("/api/track", (req, res) => {
    const { yaw, pitch, roll, ip, port } = req.body;

    if (!ip || !port) {
      return res.status(400).json({ error: "IP and Port required" });
    }

    // OpenTrack UDP format: 6 floats (yaw, pitch, roll, x, y, z) in little-endian
    const buffer = Buffer.alloc(24); // 6 * 4 bytes
    buffer.writeFloatLE(yaw || 0, 0);
    buffer.writeFloatLE(pitch || 0, 4);
    buffer.writeFloatLE(roll || 0, 8);
    buffer.writeFloatLE(0, 12); // x
    buffer.writeFloatLE(0, 16); // y
    buffer.writeFloatLE(0, 20); // z

    // Sample logging to avoid spam
    if (Math.random() < 0.01) {
      console.log(`Forwarding to ${ip}:${port} - Yaw: ${yaw?.toFixed(2)}, Pitch: ${pitch?.toFixed(2)}, Roll: ${roll?.toFixed(2)}`);
    }

    udpClient.send(buffer, port, ip, (err) => {
      if (err) {
        console.error("UDP Send Error:", err);
        return res.status(500).json({ error: "Failed to send UDP" });
      }
      res.json({ status: "ok" });
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
